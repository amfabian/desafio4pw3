package br.edu.ifrs.pw3.desafio4pw3.util;

public class Cliente {

    public static String nome = "";
    public static String email = "";
    public static String cpf = "";

    public static String endereco ="";
    public static String enderecoLinha2 = "";
    public static String cidade = "";
    public static String cep = "";

    public static boolean primeiroLogin = true;
}
